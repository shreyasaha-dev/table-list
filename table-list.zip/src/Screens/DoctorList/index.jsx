import React from "react";
import { useDispatch, useSelector } from "react-redux";
import { useNavigate } from "react-router-dom";
import TableRow from "../../Components/TableRow";
import "./doctorList.css";
import { actions } from "../../Store/ScheduleReducer";
const DoctorList = () => {
  const navigate = useNavigate();
  const dispatch = useDispatch();
  const createData = useSelector((state) => state.createData);
  const deleteHandler = (item) => {
    dispatch(actions.deleteData(item.id));
  };
  return (
    <div className="total-list">
      <div className="list-middle-section">
        <button
          onClick={() => {
            navigate("/create");
          }}
        >
          + Add Schedule
        </button>
        <div className="table-section">
          <table>
            <thead>
              <tr>
                <th>Patient Name</th>
                <th>Phone Number</th>
                <th>Doctor's Name</th>
                <th>Date</th>
                <th>Issue</th>
                <th colSpan="2">Actions</th>
              </tr>
            </thead>
            <tbody>
              {createData.length === 0 ? (
                <p>No Data Yet</p>
              ) : (
                createData?.map((item) => {
                  return (
                    <TableRow
                      name={item.patient}
                      number={item.phone}
                      date={item.date}
                      issue={item.message}
                      doctor={item.doctor}
                      id={item.id}
                      deleteHandler={() => {
                        deleteHandler(item);
                      }}
                    />
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default DoctorList;
